# model.py
from pydantic import BaseModel
from typing import List, Optional

# 강의실 모델
class Classroom(BaseModel):
    building: str
    classroomNo: str
    capacity: int
    group: int
    forGrad: Optional[int] = 0  # 기본값 0

# 교수 모델
class Professor(BaseModel):
    profCode: str
    name: str
    isprof: Optional[bool] = False
    lectureCnt: Optional[int] = 0
    free: Optional[List[List[bool]]] = []
    hope: Optional[List[List[bool]]] = []

# 강의 모델
class Lecture(BaseModel):
    lectureCode: str
    division: int
    TP: int
    name: str
    grade: int
    MR: bool
    group: int
    duration: int
    capacity: int
    profCode: str
    isTPGroup: Optional[bool] = False
    isgrad: Optional[bool] = False
    gradClassrooms: Optional[List[str]] = []
    atNight: Optional[bool] = False
    isFixedTime: Optional[bool] = False
    FixedTime: Optional[List[int]] = []
    isFixedSpace: Optional[bool] = False
    FixedSpace: Optional[List[str]] = []
    available: Optional[List] = []
    batched: Optional[List] = []

# 완성된 시간표 모델
class CompletedSchedule(BaseModel):
    lecture_id: str  # 강의 ID (lectureCode)
    professor_id: str  # 교수 ID (profCode)
    classroom_id: str  # 강의실 ID (classroomNo)
    day: int  # 요일 (1: 월요일 ~ 5: 금요일)
    period: int  # 교시 (1교시부터)

# 시간표 모델
class Timetable(BaseModel):
    id: str  # 시간표 ID
    password: str  # 비밀번호
    description: Optional[str] = None  # 설명
    lectures: List[Lecture] = []  # 강의 목록
    classrooms: List[Classroom] = []  # 강의실 목록
    professors: List[Professor] = []  # 교수 목록
    completed_schedules: List[CompletedSchedule] = []  # 완성된 시간표 목록